DROP TABLE `#__gcalendar`;
